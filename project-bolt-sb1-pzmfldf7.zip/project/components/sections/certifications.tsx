"use client";

import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Award, ExternalLink } from 'lucide-react';
import { 
  Card, 
  CardContent, 
  CardFooter,
  CardHeader,
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const certifications = [
  {
    id: 1,
    title: "Advanced Frontend Architecture",
    organization: "Frontend Masters",
    date: "2023",
    logo: <Award className="h-12 w-12 text-primary" />,
    url: "#"
  },
  {
    id: 2,
    title: "UI/UX Design Professional",
    organization: "Interaction Design Foundation",
    date: "2022",
    logo: <Award className="h-12 w-12 text-primary" />,
    url: "#"
  },
  {
    id: 3,
    title: "Three.js and WebGL Mastery",
    organization: "Creative Coding Institute",
    date: "2022",
    logo: <Award className="h-12 w-12 text-primary" />,
    url: "#"
  },
  {
    id: 4,
    title: "AWS Cloud Practitioner",
    organization: "Amazon Web Services",
    date: "2021",
    logo: <Award className="h-12 w-12 text-primary" />,
    url: "#"
  }
];

const CertificationCard = ({ cert, index }: { cert: any, index: number }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Card className="h-full border-border/40 bg-card/80 backdrop-blur-sm hover:shadow-md transition-all duration-300">
        <CardHeader className="p-6 pb-2 flex flex-row items-start justify-between">
          <div>
            <CardTitle className="text-xl font-bold font-space">{cert.title}</CardTitle>
            <p className="text-muted-foreground mt-1">{cert.organization}</p>
          </div>
          {cert.logo}
        </CardHeader>
        
        <CardContent className="p-6 pt-2">
          <p className="text-sm text-muted-foreground">Issued: {cert.date}</p>
        </CardContent>
        
        <CardFooter className="p-6 pt-0">
          <Button variant="outline" size="sm" className="w-full group" asChild>
            <a href={cert.url} target="_blank" rel="noopener noreferrer">
              View Certificate
              <ExternalLink className="ml-2 h-3.5 w-3.5 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </a>
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

const Certifications = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });
  
  const headerY = useTransform(
    scrollYProgress, 
    [0, 0.1, 0.9, 1], 
    [100, 0, 0, -100]
  );
  
  return (
    <section id="certifications" className="py-20 relative bg-muted/30" ref={containerRef}>
      <div className="container mx-auto px-4">
        <motion.div 
          className="max-w-3xl mx-auto text-center mb-16"
          style={{ y: headerY }}
        >
          <motion.h2 
            className="text-3xl md:text-4xl font-bold mb-4 font-space"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            Certifications
          </motion.h2>
          <motion.p 
            className="text-muted-foreground max-w-xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            Professional certifications and credentials that validate
            my skills and expertise.
          </motion.p>
        </motion.div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {certifications.map((cert, index) => (
            <CertificationCard key={cert.id} cert={cert} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Certifications;
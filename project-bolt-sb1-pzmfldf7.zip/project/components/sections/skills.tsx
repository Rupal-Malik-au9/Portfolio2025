"use client";

import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Globe, 
  Code, 
  Palette, 
  Database, 
  LineChart, 
  Layers,
  Cpu,
  Github
} from 'lucide-react';

const skillsData = [
  {
    category: "Frontend Development",
    icon: <Code className="h-6 w-6" />,
    skills: [
      { name: "React/Next.js", level: 90 },
      { name: "TypeScript", level: 85 },
      { name: "HTML/CSS/SASS", level: 95 },
      { name: "Vue.js", level: 80 },
      { name: "Three.js/WebGL", level: 75 },
    ]
  },
  {
    category: "UI/UX Design",
    icon: <Palette className="h-6 w-6" />,
    skills: [
      { name: "Figma/Adobe XD", level: 85 },
      { name: "Interface Design", level: 90 },
      { name: "Design Systems", level: 80 },
      { name: "Motion Design", level: 75 },
      { name: "Accessibility", level: 85 },
    ]
  },
  {
    category: "Backend & APIs",
    icon: <Database className="h-6 w-6" />,
    skills: [
      { name: "Node.js/Express", level: 80 },
      { name: "GraphQL", level: 75 },
      { name: "REST API Design", level: 85 },
      { name: "MongoDB", level: 70 },
      { name: "Firebase", level: 80 },
    ]
  },
  {
    category: "Other Skills",
    icon: <Globe className="h-6 w-6" />,
    skills: [
      { name: "Git/GitHub", level: 90 },
      { name: "CI/CD Pipelines", level: 75 },
      { name: "Performance Optimization", level: 80 },
      { name: "SEO", level: 70 },
      { name: "Testing (Jest, Cypress)", level: 75 },
    ]
  }
];

interface SkillBarProps {
  name: string;
  level: number;
  index: number;
}

const SkillBar = ({ name, level, index }: SkillBarProps) => {
  return (
    <motion.div 
      className="mb-3"
      initial={{ opacity: 0, x: -50 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <div className="flex justify-between mb-1">
        <span className="text-sm font-medium">{name}</span>
        <span className="text-xs text-muted-foreground">{level}%</span>
      </div>
      <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
        <motion.div 
          className="h-full bg-gradient-to-r from-primary to-purple-500"
          initial={{ width: 0 }}
          whileInView={{ width: `${level}%` }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.2 + index * 0.1 }}
        />
      </div>
    </motion.div>
  );
};

interface SkillCategoryProps {
  category: string;
  icon: React.ReactNode;
  skills: Array<{ name: string; level: number }>;
  index: number;
}

const SkillCategory = ({ category, icon, skills, index }: SkillCategoryProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Card className="h-full border-border/40 bg-card/80 backdrop-blur-sm hover:shadow-md transition-all duration-300">
        <CardContent className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-md bg-primary/10 text-primary">
              {icon}
            </div>
            <h3 className="text-xl font-bold font-space">{category}</h3>
          </div>
          
          <div>
            {skills.map((skill, idx) => (
              <SkillBar 
                key={skill.name} 
                name={skill.name} 
                level={skill.level} 
                index={idx} 
              />
            ))}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

// Technologies with logos
const technologies = [
  { name: "React", icon: <Code className="h-5 w-5" /> },
  { name: "Next.js", icon: <Globe className="h-5 w-5" /> },
  { name: "TypeScript", icon: <Code className="h-5 w-5" /> },
  { name: "Three.js", icon: <Layers className="h-5 w-5" /> },
  { name: "Node.js", icon: <Cpu className="h-5 w-5" /> },
  { name: "GraphQL", icon: <Database className="h-5 w-5" /> },
  { name: "Figma", icon: <Palette className="h-5 w-5" /> },
  { name: "Git", icon: <Github className="h-5 w-5" /> },
  { name: "Jest", icon: <LineChart className="h-5 w-5" /> },
];

const TechBadge = ({ tech, index }: { tech: any, index: number }) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
      className="flex items-center gap-2 px-4 py-2 rounded-full bg-secondary text-secondary-foreground shadow-sm"
    >
      {tech.icon}
      <span className="text-sm font-medium">{tech.name}</span>
    </motion.div>
  );
};

const Skills = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });
  
  const headerY = useTransform(
    scrollYProgress, 
    [0, 0.1, 0.9, 1], 
    [100, 0, 0, -100]
  );
  
  return (
    <section id="skills" className="py-20 relative bg-muted/30" ref={containerRef}>
      <div className="container mx-auto px-4">
        <motion.div 
          className="max-w-3xl mx-auto text-center mb-16"
          style={{ y: headerY }}
        >
          <motion.h2 
            className="text-3xl md:text-4xl font-bold mb-4 font-space"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            Skills & Expertise
          </motion.h2>
          <motion.p 
            className="text-muted-foreground max-w-xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            A comprehensive overview of my technical skills and proficiencies 
            in various technologies and methodologies.
          </motion.p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {skillsData.map((category, index) => (
            <SkillCategory 
              key={category.category}
              category={category.category}
              icon={category.icon}
              skills={category.skills}
              index={index}
            />
          ))}
        </div>
        
        <motion.div 
          className="bg-card/60 backdrop-blur-sm border border-border/40 rounded-lg p-8 shadow-lg"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <h3 className="text-xl font-bold mb-6 text-center font-space">Technologies I Work With</h3>
          <div className="flex flex-wrap justify-center gap-3">
            {technologies.map((tech, index) => (
              <TechBadge key={tech.name} tech={tech} index={index} />
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Skills;
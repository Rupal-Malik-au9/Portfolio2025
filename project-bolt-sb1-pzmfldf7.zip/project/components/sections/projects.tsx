"use client";

import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { ExternalLink, Github } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const projectsData = [
  {
    id: 1,
    title: "Immersive E-Learning Platform",
    description: "An interactive learning platform with 3D visualizations and gamified elements to enhance the educational experience.",
    image: "https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    tags: ["React", "Three.js", "Node.js", "MongoDB"],
    liveUrl: "https://example.com",
    repoUrl: "https://github.com",
  },
  {
    id: 2,
    title: "AI-Powered Health Tracker",
    description: "A health tracking application that uses machine learning to provide personalized recommendations and insights.",
    image: "https://images.pexels.com/photos/7014337/pexels-photo-7014337.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    tags: ["React Native", "TensorFlow.js", "Firebase", "Expo"],
    liveUrl: "https://example.com",
    repoUrl: "https://github.com",
  },
  {
    id: 3,
    title: "Smart Home Dashboard",
    description: "A comprehensive dashboard for controlling and monitoring smart home devices with voice commands and automation.",
    image: "https://images.pexels.com/photos/7054776/pexels-photo-7054776.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    tags: ["Vue.js", "WebSockets", "Express", "MQTT"],
    liveUrl: "https://example.com",
    repoUrl: "https://github.com",
  },
  {
    id: 4,
    title: "Crypto Trading Simulator",
    description: "A realistic cryptocurrency trading simulator with real-time market data and portfolio analytics.",
    image: "https://images.pexels.com/photos/8370752/pexels-photo-8370752.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    tags: ["Next.js", "WebSockets", "API Integration", "Chart.js"],
    liveUrl: "https://example.com",
    repoUrl: "https://github.com",
  }
];

const ProjectCard = ({ project, index }: { project: any, index: number }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: cardRef,
    offset: ["start end", "end start"]
  });
  
  const y = useTransform(
    scrollYProgress, 
    [0, 1], 
    [50, -50]
  );
  
  const opacity = useTransform(
    scrollYProgress, 
    [0, 0.2, 0.8, 1], 
    [0.6, 1, 1, 0.6]
  );
  
  const scale = useTransform(
    scrollYProgress, 
    [0, 0.2, 0.8, 1], 
    [0.95, 1, 1, 0.95]
  );
  
  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.8, delay: index * 0.1 }}
      style={{ y, opacity, scale }}
      className="w-full group"
    >
      <Card className="overflow-hidden border-border/40 bg-card/80 backdrop-blur-sm transition-all duration-300 hover:shadow-xl">
        <div className="relative aspect-video overflow-hidden">
          <img 
            src={project.image} 
            alt={project.title} 
            className="object-cover w-full h-full transform transition-transform duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-60" />
        </div>
        
        <CardContent className="p-6">
          <h3 className="text-xl font-bold mb-2 font-space">{project.title}</h3>
          <p className="text-muted-foreground mb-4">{project.description}</p>
          
          <div className="flex flex-wrap gap-2 mb-6">
            {project.tags.map((tag: string) => (
              <Badge key={tag} variant="secondary" className="font-medium">
                {tag}
              </Badge>
            ))}
          </div>
          
          <div className="flex gap-3">
            <Button variant="outline" size="sm" className="group" asChild>
              <a href={project.liveUrl} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="mr-1 h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
                View Live
              </a>
            </Button>
            <Button variant="ghost" size="sm" className="group" asChild>
              <a href={project.repoUrl} target="_blank" rel="noopener noreferrer">
                <Github className="mr-1 h-4 w-4 transition-transform group-hover:scale-110" />
                Repository
              </a>
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

const Projects = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });
  
  const headerY = useTransform(
    scrollYProgress, 
    [0, 0.1, 0.9, 1], 
    [100, 0, 0, -100]
  );
  
  return (
    <section id="projects" className="py-20 relative" ref={containerRef}>
      <div className="container mx-auto px-4">
        <motion.div 
          className="max-w-3xl mx-auto text-center mb-16"
          style={{ y: headerY }}
        >
          <motion.h2 
            className="text-3xl md:text-4xl font-bold mb-4 font-space"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            Featured Projects
          </motion.h2>
          <motion.p 
            className="text-muted-foreground max-w-xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            Explore a collection of my most impactful work, showcasing my skills in 
            frontend development, interactive design, and modern technologies.
          </motion.p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projectsData.map((project, index) => (
            <ProjectCard key={project.id} project={project} index={index} />
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Button variant="outline" size="lg" className="font-medium" asChild>
            <a href="https://github.com" target="_blank" rel="noopener noreferrer">
              View More Projects on GitHub
              <Github className="ml-2 h-4 w-4" />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Projects;
"use client";

import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { ArrowDownIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import HeroCanvas from '@/components/three/hero-canvas';

const Hero = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  const scrollToProjects = () => {
    const projectsSection = document.getElementById('projects');
    if (projectsSection) {
      projectsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Text animation variants
  const titleVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { 
        duration: 0.8, 
        ease: [0.22, 1, 0.36, 1],
      }
    }
  };

  const subtitleVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { 
        duration: 0.8, 
        delay: 0.2, 
        ease: [0.22, 1, 0.36, 1],
      }
    }
  };

  const buttonVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { 
        duration: 0.8, 
        delay: 0.4, 
        ease: [0.22, 1, 0.36, 1],
      }
    }
  };

  return (
    <section className="relative min-h-screen flex items-center" ref={containerRef}>
      {/* 3D Background Animation */}
      <div className="absolute inset-0 z-0">
        <HeroCanvas />
      </div>
      
      {/* Content */}
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl">
          <motion.h1 
            className="text-4xl md:text-6xl font-bold leading-tight font-space tracking-tight"
            initial="hidden"
            animate="visible"
            variants={titleVariants}
          >
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-500">
              Crafting Digital Experiences
            </span>{' '}
            with Code & Design
          </motion.h1>
          
          <motion.p 
            className="mt-6 text-xl text-muted-foreground max-w-2xl"
            initial="hidden"
            animate="visible"
            variants={subtitleVariants}
          >
            Frontend developer and UX designer specializing in creating immersive, 
            interactive web experiences with cutting-edge technologies.
          </motion.p>
          
          <motion.div 
            className="mt-8 flex flex-wrap gap-4"
            initial="hidden"
            animate="visible"
            variants={buttonVariants}
          >
            <Button 
              size="lg" 
              className="font-medium text-base group"
              onClick={scrollToProjects}
            >
              View Projects
              <ArrowDownIcon className="ml-2 h-4 w-4 transition-transform group-hover:translate-y-1" />
            </Button>
            
            <Button 
              size="lg" 
              variant="outline" 
              className="font-medium text-base"
              asChild
            >
              <a href="#contact">Get in Touch</a>
            </Button>
          </motion.div>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 z-10">
        <motion.div
          className="flex flex-col items-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
        >
          <span className="text-sm text-muted-foreground mb-2">Scroll to explore</span>
          <motion.div
            className="w-6 h-10 border-2 border-primary/50 rounded-full flex justify-center p-1"
            initial={{ y: 0 }}
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
          >
            <motion.div className="w-1 h-1 bg-primary rounded-full" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
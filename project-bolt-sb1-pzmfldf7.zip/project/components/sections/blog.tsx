"use client";

import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { CalendarIcon, Clock, ArrowUpRight, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { 
  Card, 
  CardContent, 
  CardFooter,
  CardHeader,
  CardTitle 
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow } from 'date-fns';

const blogPosts = [
  {
    id: 1,
    title: "Crafting Immersive 3D Web Experiences with Three.js",
    excerpt: "Explore techniques for creating engaging 3D visualizations that enhance user experience without compromising performance.",
    image: "https://images.pexels.com/photos/7148384/pexels-photo-7148384.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    date: new Date("2023-11-15"),
    readTime: 8,
    tags: ["Three.js", "WebGL", "Performance"],
    url: "#"
  },
  {
    id: 2,
    title: "Building Accessible UI Components from Scratch",
    excerpt: "Learn how to create custom UI components that are both visually striking and fully accessible for all users.",
    image: "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    date: new Date("2023-10-22"),
    readTime: 12,
    tags: ["Accessibility", "UI Components", "React"],
    url: "#"
  },
  {
    id: 3,
    title: "Optimizing React Performance for Complex Applications",
    excerpt: "Proven strategies to identify and resolve performance bottlenecks in large-scale React applications.",
    image: "https://images.pexels.com/photos/11035471/pexels-photo-11035471.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    date: new Date("2023-09-10"),
    readTime: 10,
    tags: ["React", "Performance", "Optimization"],
    url: "#"
  }
];

const BlogCard = ({ post, index }: { post: any, index: number }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Card className="h-full overflow-hidden border-border/40 flex flex-col hover:shadow-lg transition-all duration-300 group">
        <div className="relative aspect-[16/9] overflow-hidden">
          <img 
            src={post.image} 
            alt={post.title} 
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
        </div>
        
        <CardHeader className="p-6 pb-2">
          <div className="flex flex-wrap gap-2 mb-3">
            {post.tags.map((tag: string) => (
              <Badge key={tag} variant="secondary" className="font-medium text-xs">
                {tag}
              </Badge>
            ))}
          </div>
          <CardTitle className="text-xl font-bold mb-2 group-hover:text-primary transition-colors duration-300">
            {post.title}
          </CardTitle>
        </CardHeader>
        
        <CardContent className="p-6 pt-0 flex-grow">
          <p className="text-muted-foreground line-clamp-3">{post.excerpt}</p>
        </CardContent>
        
        <CardFooter className="p-6 pt-2 flex justify-between items-center">
          <div className="flex items-center text-sm text-muted-foreground">
            <CalendarIcon className="h-3.5 w-3.5 mr-1" />
            <time dateTime={post.date.toISOString()}>
              {formatDistanceToNow(post.date, { addSuffix: true })}
            </time>
            <span className="mx-2">•</span>
            <Clock className="h-3.5 w-3.5 mr-1" />
            <span>{post.readTime} min read</span>
          </div>
          
          <Button variant="ghost" size="sm" className="gap-1 p-0 h-auto" asChild>
            <a href={post.url}>
              Read
              <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

const Blog = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });
  
  const headerY = useTransform(
    scrollYProgress, 
    [0, 0.1, 0.9, 1], 
    [100, 0, 0, -100]
  );
  
  return (
    <section id="blog" className="py-20 relative" ref={containerRef}>
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap justify-between items-center mb-12">
          <motion.div 
            className="max-w-2xl"
            style={{ y: headerY }}
          >
            <motion.h2 
              className="text-3xl md:text-4xl font-bold mb-4 font-space"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              Latest Articles
            </motion.h2>
            <motion.p 
              className="text-muted-foreground"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              Thoughts, insights, and perspectives on web development,
              design, and emerging technologies.
            </motion.p>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Button variant="outline" className="group" asChild>
              <a href="#">
                View All Posts
                <ChevronRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </a>
            </Button>
          </motion.div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post, index) => (
            <BlogCard key={post.id} post={post} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Blog;
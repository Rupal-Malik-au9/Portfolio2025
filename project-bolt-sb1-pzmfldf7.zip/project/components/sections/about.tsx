"use client";

import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { 
  Book, 
  Calendar, 
  GraduationCap, 
  Briefcase, 
  Award,
  FileText,
  ArrowDownToLine
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';

const aboutData = {
  bio: `
    I'm a passionate frontend developer and UX designer with over 5 years of experience creating
    immersive digital experiences. My approach combines technical expertise with a strong design
    sensibility to build applications that are both visually stunning and highly functional.
    
    My journey in web development began with a curiosity about how digital interfaces could
    enhance human experiences. Since then, I've dedicated myself to mastering frontend technologies
    and design principles to create websites and applications that surprise and delight users.
    
    When I'm not coding, you can find me exploring new design trends, contributing to open-source
    projects, or experimenting with emerging web technologies.
  `,
  experience: [
    {
      title: "Senior Frontend Developer",
      company: "Tech Innovations Inc.",
      period: "2021 - Present",
      description: "Leading frontend development for enterprise applications with React, TypeScript, and Three.js. Implemented CI/CD pipelines and established coding standards that improved development efficiency by 35%."
    },
    {
      title: "UX Engineer",
      company: "Creative Digital Studio",
      period: "2019 - 2021",
      description: "Designed and developed interactive web experiences for clients in retail and entertainment. Created reusable component libraries and design systems that reduced project timelines by 40%."
    },
    {
      title: "Frontend Developer",
      company: "WebSolutions Agency",
      period: "2017 - 2019",
      description: "Built responsive websites and e-commerce platforms using React, Vue.js, and WordPress. Collaborated with designers to implement pixel-perfect interfaces and animations."
    }
  ],
  education: [
    {
      degree: "Master of Science in Human-Computer Interaction",
      institution: "Tech University",
      year: "2017",
      description: "Focused on interactive design, cognitive psychology, and frontend development. Thesis on immersive web experiences using WebGL and 3D technologies."
    },
    {
      degree: "Bachelor of Science in Computer Science",
      institution: "State University",
      year: "2015",
      description: "Specialized in web development and software engineering. Graduated cum laude with honors in interactive media design."
    }
  ],
  awards: [
    {
      title: "Web Excellence Award",
      year: "2022",
      organization: "International Web Association",
      description: "Recognized for innovative use of 3D graphics in e-commerce experience."
    },
    {
      title: "Best UI/UX Design",
      year: "2020",
      organization: "Design Awards",
      description: "Awarded for exceptional user interface design in a healthcare application."
    }
  ]
};

const Experience = () => {
  return (
    <div className="space-y-8">
      {aboutData.experience.map((job, index) => (
        <motion.div 
          key={index}
          className="relative pl-8 border-l border-border pb-8 last:pb-0"
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
        >
          <div className="absolute -left-3 top-0 w-6 h-6 rounded-full bg-primary/10 border border-primary flex items-center justify-center">
            <Briefcase className="h-3 w-3 text-primary" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <h3 className="text-lg font-bold font-space">{job.title}</h3>
              <span className="text-sm text-muted-foreground">• {job.company}</span>
            </div>
            <div className="flex items-center text-sm text-muted-foreground mb-3">
              <Calendar className="h-3.5 w-3.5 mr-1" />
              <span>{job.period}</span>
            </div>
            <p className="text-muted-foreground">{job.description}</p>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

const Education = () => {
  return (
    <div className="space-y-8">
      {aboutData.education.map((edu, index) => (
        <motion.div 
          key={index}
          className="relative pl-8 border-l border-border pb-8 last:pb-0"
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
        >
          <div className="absolute -left-3 top-0 w-6 h-6 rounded-full bg-primary/10 border border-primary flex items-center justify-center">
            <GraduationCap className="h-3 w-3 text-primary" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <h3 className="text-lg font-bold font-space">{edu.degree}</h3>
            </div>
            <div className="flex items-center text-sm text-muted-foreground mb-3">
              <Book className="h-3.5 w-3.5 mr-1" />
              <span>{edu.institution}, {edu.year}</span>
            </div>
            <p className="text-muted-foreground">{edu.description}</p>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

const Awards = () => {
  return (
    <div className="space-y-8">
      {aboutData.awards.map((award, index) => (
        <motion.div 
          key={index}
          className="relative pl-8 border-l border-border pb-8 last:pb-0"
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
        >
          <div className="absolute -left-3 top-0 w-6 h-6 rounded-full bg-primary/10 border border-primary flex items-center justify-center">
            <Award className="h-3 w-3 text-primary" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <h3 className="text-lg font-bold font-space">{award.title}</h3>
              <span className="text-sm text-muted-foreground">• {award.organization}</span>
            </div>
            <div className="flex items-center text-sm text-muted-foreground mb-3">
              <Calendar className="h-3.5 w-3.5 mr-1" />
              <span>{award.year}</span>
            </div>
            <p className="text-muted-foreground">{award.description}</p>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

const About = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });
  
  const headerY = useTransform(
    scrollYProgress, 
    [0, 0.1, 0.9, 1], 
    [100, 0, 0, -100]
  );
  
  return (
    <section id="about" className="py-20 relative" ref={containerRef}>
      <div className="container mx-auto px-4">
        <motion.div 
          className="max-w-3xl mx-auto text-center mb-16"
          style={{ y: headerY }}
        >
          <motion.h2 
            className="text-3xl md:text-4xl font-bold mb-4 font-space"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            About Me
          </motion.h2>
          <motion.p 
            className="text-muted-foreground max-w-xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            Learn more about my journey, experience, and qualifications
            in web development and design.
          </motion.p>
        </motion.div>
        
        <div className="grid grid-cols-1 lg:grid-cols-7 gap-12">
          {/* Bio and Image */}
          <motion.div 
            className="lg:col-span-3"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div className="aspect-square w-full max-w-md mx-auto lg:mx-0 mb-8 lg:mb-0 rounded-2xl overflow-hidden">
              <img 
                src="https://images.pexels.com/photos/4195342/pexels-photo-4195342.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Developer portrait" 
                className="w-full h-full object-cover"
              />
            </div>
            
            <div className="mt-6 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button className="gap-2" asChild>
                <a href="#contact">
                  Contact Me
                </a>
              </Button>
              <Button variant="outline" className="gap-2">
                <FileText className="h-4 w-4" />
                <a href="#" download>
                  Download CV
                </a>
                <ArrowDownToLine className="h-4 w-4 ml-1" />
              </Button>
            </div>
          </motion.div>
          
          {/* Bio and Tabs */}
          <motion.div 
            className="lg:col-span-4"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div className="mb-8">
              <h3 className="text-2xl font-bold mb-4 font-space">My Story</h3>
              <div className="space-y-4 text-muted-foreground">
                {aboutData.bio.split('\n\n').map((paragraph, index) => (
                  <p key={index}>{paragraph}</p>
                ))}
              </div>
            </div>
            
            <Tabs defaultValue="experience" className="w-full">
              <TabsList className="w-full grid grid-cols-3">
                <TabsTrigger value="experience">Experience</TabsTrigger>
                <TabsTrigger value="education">Education</TabsTrigger>
                <TabsTrigger value="awards">Awards</TabsTrigger>
              </TabsList>
              <div className="mt-6">
                <TabsContent value="experience" className="focus:outline-none">
                  <Experience />
                </TabsContent>
                <TabsContent value="education" className="focus:outline-none">
                  <Education />
                </TabsContent>
                <TabsContent value="awards" className="focus:outline-none">
                  <Awards />
                </TabsContent>
              </div>
            </Tabs>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;
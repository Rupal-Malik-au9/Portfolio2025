"use client";

import { useEffect, useState } from 'react';
import { useToast } from '@/hooks/use-toast';

interface Command {
  command: string;
  action: () => void;
}

export function VoiceCommands() {
  const { toast } = useToast();
  const [listening, setListening] = useState(false);
  const [recognition, setRecognition] = useState<any>(null);

  useEffect(() => {
    // Check if browser supports SpeechRecognition
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      // Create speech recognition instance
      const SpeechRecognition = window.webkitSpeechRecognition || window.SpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      
      // Configure
      recognitionInstance.continuous = true;
      recognitionInstance.interimResults = false;
      recognitionInstance.lang = 'en-US';
      
      // Set the recognition instance
      setRecognition(recognitionInstance);
      
      // Start listening
      try {
        recognitionInstance.start();
        setListening(true);
        
        toast({
          title: "Voice commands enabled",
          description: "Try saying: 'scroll to projects', 'contact', 'about', 'home', or 'toggle theme'",
        });
      } catch (error) {
        console.error("Error starting speech recognition:", error);
      }
    } else {
      toast({
        title: "Voice commands not supported",
        description: "Your browser doesn't support voice recognition.",
        variant: "destructive",
      });
    }
    
    return () => {
      if (recognition) {
        recognition.stop();
      }
    };
  }, []);

  useEffect(() => {
    if (!recognition) return;
    
    // Define commands
    const commands: Command[] = [
      {
        command: 'scroll to projects',
        action: () => scrollToSection('projects')
      },
      {
        command: 'projects',
        action: () => scrollToSection('projects')
      },
      {
        command: 'skills',
        action: () => scrollToSection('skills')
      },
      {
        command: 'scroll to skills',
        action: () => scrollToSection('skills')
      },
      {
        command: 'about',
        action: () => scrollToSection('about')
      },
      {
        command: 'scroll to about',
        action: () => scrollToSection('about')
      },
      {
        command: 'contact',
        action: () => scrollToSection('contact')
      },
      {
        command: 'scroll to contact',
        action: () => scrollToSection('contact')
      },
      {
        command: 'home',
        action: () => window.scrollTo({ top: 0, behavior: 'smooth' })
      },
      {
        command: 'go to top',
        action: () => window.scrollTo({ top: 0, behavior: 'smooth' })
      },
      {
        command: 'toggle theme',
        action: () => {
          const theme = document.documentElement.classList.contains('dark') ? 'light' : 'dark';
          document.documentElement.classList.toggle('dark');
          
          toast({
            title: `Theme changed`,
            description: `Switched to ${theme} mode`,
          });
        }
      }
    ];
    
    // Process speech results
    recognition.onresult = (event: any) => {
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript.toLowerCase().trim();
        console.log('Voice command detected:', transcript);
        
        // Find matching command
        const matchedCommand = commands.find(cmd => 
          transcript.includes(cmd.command)
        );
        
        if (matchedCommand) {
          matchedCommand.action();
          
          toast({
            title: "Command recognized",
            description: `Executing: "${matchedCommand.command}"`,
          });
          
          break;
        }
      }
    };
    
    recognition.onend = () => {
      if (listening) {
        recognition.start();
      }
    };
    
    recognition.onerror = (event: any) => {
      console.error("Speech recognition error", event.error);
      setListening(false);
      
      toast({
        title: "Voice recognition error",
        description: event.error,
        variant: "destructive",
      });
    };
    
  }, [recognition, listening]);
  
  const scrollToSection = (sectionId: string) => {
    const section = document.getElementById(sectionId);
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  };
  
  return null; // This component doesn't render anything visible
}
"use client";

import { useRef, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Points } from '@react-three/drei';
import { useTheme } from 'next-themes';
import { Vector3, MathUtils, Color } from 'three';
import { EffectComposer, Bloom } from '@react-three/postprocessing';

// Particle component
const Particles = ({ count = 3000, theme }: { count: number; theme: string }) => {
  const mesh = useRef<any>();
  const { viewport } = useThree();
  
  // Generate particles
  const particlePositions = Array.from({ length: count }, () => ({
    position: [
      (Math.random() - 0.5) * 10,
      (Math.random() - 0.5) * 10,
      (Math.random() - 0.5) * 10
    ],
    speed: Math.random() * 0.002 + 0.001,
    offset: Math.random() * Math.PI * 2,
    scale: Math.random() * 0.4 + 0.1,
    opacity: Math.random() * 0.5 + 0.3
  }));
  
  useFrame(({ clock }) => {
    if (!mesh.current) return;
    
    const elapsedTime = clock.getElapsedTime();
    
    // Update each particle
    for (let i = 0; i < mesh.current.count; i++) {
      const i3 = i * 3;
      const particle = particlePositions[i];
      
      // Update z position for floating effect
      mesh.current.geometry.attributes.position.array[i3 + 2] += 
        Math.sin(elapsedTime * particle.speed + particle.offset) * 0.01;
        
      // Update opacity for twinkling effect
      const opacityIndex = i;
      if (mesh.current.geometry.attributes.opacity) {
        mesh.current.geometry.attributes.opacity.array[opacityIndex] = 
          MathUtils.lerp(
            mesh.current.geometry.attributes.opacity.array[opacityIndex],
            0.3 + Math.sin(elapsedTime * 0.5 + particle.offset) * 0.2,
            0.1
          );
      }
    }
    
    mesh.current.geometry.attributes.position.needsUpdate = true;
    if (mesh.current.geometry.attributes.opacity) {
      mesh.current.geometry.attributes.opacity.needsUpdate = true;
    }
  });
  
  // Colors based on theme
  const colorPrimary = theme === 'dark' 
    ? new Color(0x3388ff)  // Blue for dark mode
    : new Color(0xff3366);  // Pink for light mode
    
  const colorSecondary = theme === 'dark' 
    ? new Color(0x33aaff)  // Lighter blue for dark mode
    : new Color(0xff6644);  // Orange for light mode

  return (
    <Points ref={mesh}>
      <bufferGeometry>
        <bufferAttribute 
          attach="attributes-position" 
          count={count}
          array={new Float32Array(particlePositions.map(p => p.position).flat())}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-opacity"
          count={count}
          array={new Float32Array(particlePositions.map(p => p.opacity))}
          itemSize={1}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.05}
        transparent
        depthWrite={false}
        vertexColors
        blending={2}
        opacity={1}
      />
    </Points>
  );
};

// Mouse follower
const MouseLight = () => {
  const light = useRef<any>();
  const { viewport, mouse } = useThree();
  
  useFrame(() => {
    if (light.current) {
      light.current.position.x = mouse.x * viewport.width / 2;
      light.current.position.y = mouse.y * viewport.height / 2;
    }
  });
  
  return (
    <pointLight
      ref={light}
      distance={10}
      intensity={5}
      color="#ffffff"
    />
  );
};

// Main canvas component
const HeroCanvas = () => {
  const { theme } = useTheme();
  
  return (
    <Canvas camera={{ position: [0, 0, 5], fov: 75 }}>
      <color attach="background" args={[theme === 'dark' ? '#050505' : '#fafafa']} />
      <fog attach="fog" args={[theme === 'dark' ? '#050505' : '#fafafa', 3, 15]} />
      
      <ambientLight intensity={0.2} />
      <MouseLight />
      
      <Particles count={3000} theme={theme || 'dark'} />
      
      <EffectComposer>
        <Bloom
          intensity={1.5}
          luminanceThreshold={0.1}
          luminanceSmoothing={0.9}
        />
      </EffectComposer>
    </Canvas>
  );
};

export default HeroCanvas;
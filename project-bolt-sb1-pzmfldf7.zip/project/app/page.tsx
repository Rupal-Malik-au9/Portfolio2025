import Hero from '@/components/sections/hero';
import Projects from '@/components/sections/projects';
import Skills from '@/components/sections/skills';
import About from '@/components/sections/about';
import Contact from '@/components/sections/contact';
import Testimonials from '@/components/sections/testimonials';
import Blog from '@/components/sections/blog';
import Certifications from '@/components/sections/certifications';

export default function Home() {
  return (
    <div className="relative">
      <Hero />
      <Projects />
      <Skills />
      <About />
      <Testimonials />
      <Certifications />
      <Blog />
      <Contact />
    </div>
  );
}